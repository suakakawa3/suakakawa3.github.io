export { readStream } from './stream';
